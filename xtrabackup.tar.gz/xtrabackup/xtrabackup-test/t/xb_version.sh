. inc/common.sh

xtrabackup --version
